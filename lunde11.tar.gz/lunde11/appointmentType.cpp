// Author: Todd Lunde
// File: appointmentType.cpp (Prog11)
// Class: CSIS 252
// Program: assignment #11
// Date: 12/01/2018   
                                      
                                                                                                                            
// This file contains the implementation for the appointmentType class.                   

#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>

using namespace std;

#include "appointmentType.h"
#include "dateType.h"
#include "timeType.h"
#include "binarySearchTree.h"

ostream& operator<< (ostream& osObject, const appointmentType& a) 
{  
     osObject << a.getDate() << "  " << a.getTime() << "  " << a.getDescription();
    
     return osObject;
}  

appointmentType::appointmentType(const dateType& d, const timeType& t, const string& n)
{
   setDate(d);
   setTime(t);
   setDescription(n);
}

appointmentType::appointmentType(const string& n)
{
   setDescription(n);
}

string appointmentType::getDescription() const
{
   return description;
}

void appointmentType::setDescription(const string& n)
{
   description = n;
}

dateType appointmentType::getDate() const
{
   return date;
}

void appointmentType::setDate(const dateType& d)
{
   date = d;
}

timeType appointmentType::getTime() const
{
   return time;
}

void appointmentType::setTime(const timeType& t)
{
   time = t;
}


bool appointmentType::operator < (const appointmentType& a) const
{
   return (*this < a);
}

bool appointmentType::operator == (const appointmentType& a) const
{
   return (*this == a);
}

bool appointmentType::operator != (const appointmentType& a) const
{
   return (*this != a);
}

bool appointmentType::operator >= (const appointmentType& a) const
{
   return (*this >= a);
}

bool appointmentType::operator <= (const appointmentType& a) const
{
   return (*this < a) || (*this == a);
}

bool appointmentType::operator > (const appointmentType& a) const
{
   return (*this > a);
}

