// Author: Todd Lunde
// File: appointmentType.h (Prog10)
// Class: CSIS 252
// Program: assignment #10
// Date: 11/21/2018   
                                      
                                                                                                                            
// This file contains the class specifications for the appointmentType class. 

#ifndef _APPOINTMENTTYPE_H_
#define _APPOINTMENTTYPE_H_

#include <fstream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
 
using namespace std;

#include "dateType.h"
#include "timeType.h"


class appointmentType
{
   public:
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      appointmentType(const dateType&, const timeType&, const string&);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      appointmentType(const string& ="");
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      string getDescription() const;
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setDescription(const string&);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      dateType getDate() const;
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setDate(const dateType&);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      timeType getTime() const;
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setTime(const timeType&);
   
      // overload the less than operator
      bool operator < (const appointmentType&) const;
      
      // overload the equality operator
      bool operator == (const appointmentType&) const;
      
      // overload the inequality operator
      bool operator != (const appointmentType&) const;
      
      // overload the less than equal to operator
      bool operator <= (const appointmentType&) const;
      
      // overload the greater than operator
      bool operator > (const appointmentType&) const;
      
      // overload the greater than equal to operator
      bool operator >= (const appointmentType&) const;

   private:
      dateType date;
      timeType time;
      string description;
};

ostream& operator << (ostream&, const appointmentType&);

//istream& operator >> (istream&,personType&);

#endif








