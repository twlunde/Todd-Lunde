// Author: Todd Lunde
// File: read.cpp (Prog11)
// Class: CSIS 252
// Program: assignment #11
// Date: 12/01/2018   
                                      
                                                                                                                            
// This file contains function read()

#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>

using namespace std;

#include "appointmentType.h"
#include "dateType.h"
#include "timeType.h"
#include "binarySearchTree.h"


void read(bSearchTreeType<appointmentType>& appointments)      
{
   ifstream infile;
   
   int month, day, year;
   int hours, minutes;
   char dummyChar;
   string aMpM;
   string description;
   dateType date;
   timeType time;
   
   int count = 0;
   
   appointmentType appointment;
   
   bSearchTreeType<appointmentType> tree;

   
   
   infile.open("data");
   infile >> month; 
   
   while (!infile.eof())
   {
      infile >> dummyChar;  // slash
      infile >> day;  
      infile >> dummyChar; // slash 
      infile >> year; 
      date.setDate(month, day, year);
      appointment.setDate(date);
      infile >> hours;  
      infile >> dummyChar;  // colon;
      infile >> minutes;  
      time.setTime(hours, minutes);
      appointment.setTime(time);
      getline(infile, description); 
      appointment.setDescription(description);
      
      tree.insert(appointment); 
      
cout << appointment << endl;  
cout << "count: " << count << endl; 
count++;

      infile >> month;  
      
   }  // end while
   
   infile.close();     // close infile data
   
}     // end function read()

