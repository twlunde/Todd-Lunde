// Author: Todd Lunde
// File: dateType.cpp (Prog11)
// Class: CSIS 252
// Program: assignment #11
// Date: 12/01/2018   
                                      
                                                                                                                            
// This file contains the implementation for the dateType class.                   


#include "dateType.h"


ostream& operator<< (ostream& osObject, const dateType& date) 
{   
    
     string months[]={"January", "February", "March", "April",
                    "May", "June", "July", "August",
                    "September", "October", "November", "December"};
    
     osObject << months[date.getMonth()-1] << " " << date.getDay() << ", " << date.getYear();
    
     return osObject;
}  

dateType::dateType(int m, int d, int y)
{
   setMonth(m);
   setDay(d);
   setYear(y);
}

void dateType::getDate(int m, int d, int y)    // precondition: time is correct   // output in a.m/p.m. format; example - 4:30 p.m.
{
    month = m;
    day = d;
    year = y;
}

void dateType::setDate(int m, int d, int y)    // precondition: time is correct   // output in a.m/p.m. format; example - 4:30 p.m.
{
   month = m;
   day = d;
   year = y;
}

int dateType::getMonth() const
{
   return month;
}

void dateType::setMonth(int m)
{
   month = m;
}

int dateType::getDay() const
{
   return day;
}

void dateType::setDay(int d)
{
   day = d;
}

int dateType::getYear() const
{
   return year;
}

void dateType::setYear(int y)
{
    year = y;
}
