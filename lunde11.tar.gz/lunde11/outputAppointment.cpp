// Author: Todd Lunde
// File: outputAppointment.cpp (Prog11)
// Class: CSIS 252
// Program: assignment #11
// Date: 12/01/2018   
                                      
                                                                                                                            
// This file contains function outputAppointments(). 


#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>

using namespace std;

#include "appointmentType.h"
#include "dateType.h"
#include "timeType.h"
#include "binarySearchTree.h"


void outputAppointment(const bSearchTreeType<appointmentType>& appointments) 
{
    
   bSearchTreeType<appointmentType> tree;
   appointmentType appointment; 
    
   cout << "inorder traversal:\n";
   tree.inorderTraversal();                                        
   
   
}     // end function outputAppointments()   
   
