// Author: Todd Lunde
// File: function main.cpp (Prog11)
// Class: CSIS 252
// Program: assignment #11
// Date: 12/01/2018   


// Program Description: This program                                   
                                                                                                                            
// This file contains function main() that uses two functions to implement the dateType and timeType classes.                  

#include <fstream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
 
using namespace std;

#include "appointmentType.h" 
#include "dateType.h"
#include "timeType.h"
#include "binarySearchTree.h"


// This file contains function main() that calls two functions to implement dateType, timeType 
// and appointmentType classes. The program reads appointment data from an external text data file,
// converts the mm/dd/yyy date format to written out, i.e. "November 30, 2018", converts the 24-hour
// (military) format to the hh:mm format with a.m./p.m., and finally outputs the appointment schedule
// to the screen.  The program also allows the user to compare the appointment dates and times using 
// boolean functions with overloaded comparison operators.


//  function prototypes

void read(bSearchTreeType<appointmentType>&);     //  void read(bSearchTreeType<elemType>&);                                    // (appointmentType[], int& count);                        
void outputAppointment(const bSearchTreeType<appointmentType>&);    //  void outputAppointment(bSearchTreeType<elemType>&);                        // (appointmentType[], int count); 


int main()
{
    
   bSearchTreeType<appointmentType> appointments;
    
    
   read(appointments);
   outputAppointment(appointments);
       
       
   return 0;
   
}  // end function main()


