// Author: Todd Lunde
// File: timeType.cpp (Prog10)
// Class: CSIS 252
// Program: assignment #10
// Date: 11/23/2018   
                                     
                                                                                                                            
// This file contains the implementation for the time type class.                   

#include "timeType.h"


ostream& operator<< (ostream& osObject, const timeType& time)
{
    osObject << setfill('0') << time.getHours() << ":" << setw(2) << setfill('0') << time.getMinutes() << " " << time.getAmPm();
       
    return osObject;      
} 

timeType::timeType(int h, int m)     // parameterized  constructor; time is correct
{
    setHours(h);
    setMinutes(m);
}    

string timeType::getAmPm() const
{
   return aMpM;
}

void timeType::setAmPm(string& AmPm)
{
    aMpM = AmPm;
}

void timeType::getTime(int h, int m)    // precondition: time is correct   // output in a.m/p.m. format; example - 4:30 p.m.
{
    hours = h;
    minutes = m;
}

void timeType::setTime(int h, int m)    // precondition: time is correct   // output in a.m/p.m. format; example - 4:30 p.m.
{
    string AmPm;
    
    if ((h > 12) && (h < 24))
        {
           hours = h - 12;
           minutes = m;
           AmPm = "p.m.";
           setAmPm(AmPm);
        }
   
         else 
             if ((h > 0) && (h < 12) && (m >= 0) && (m <= 59))
             { 
                 hours = h;
                 minutes = m;
                 AmPm = "a.m.";
                 setAmPm(AmPm);
             }  
             
             
               else 
                  if ((h == 12) && (m >= 0) && (m <= 59))
                  { 
                    hours = h;
                    minutes = m;
                    AmPm = "p.m.";
                    setAmPm(AmPm);
                  }  
             
                  else
                     if ((h == 0) && (m > 0) && (m <= 59))   
                     {  
                        hours = h;
                        minutes = m;
            
                        AmPm = "a.m.";
                        setAmPm(AmPm);
                     }
        
                     else
                      
                        if ((h <= 0) && (m <= 0))
                        {    
                           hours = 0;
                           minutes = 0;
                           AmPm = "";
                           setAmPm(AmPm);
                           cerr << "Error - time input is incorrect " << endl;
                         }
 
 
    if ((h >= 0) && (h < 24) && (m > 0) && (m < 59))
    { 
       minutes = m;
    }    
    
    else
        if ((h == 0) && (m > 0) && (m <= 59))   
        {  
            minutes = m;
        }
        
        else
        
            if ((h > 12) && (h < 24) && (m > 0) && (m <= 59))
            {  
                minutes = m;
    
            }   
            else
                      
                if ((h <= 0) && (m <= 0))
                {    
                   hours = 0;
                   minutes = 0;
                   cerr << "Error - time input is incorrect " << endl;
                }
                
}

int timeType::getHours() const
{
   return hours;
}

void timeType::setHours(int h)
{
    hours = h;
}     

int timeType::getMinutes() const
{
    return minutes;
}    

void timeType::setMinutes(int m)
{
    minutes = m;
}    
