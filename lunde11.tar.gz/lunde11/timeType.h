// Author: Todd Lunde
// File: timeType.h (Prog10)
// Class: CSIS 252
// Program: assignment #10
// Date: 11/21/2018   
                                      
                                                                                                                            
// This file contains the class specification for the timeType class.                  

#include <fstream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
 
using namespace std;

#ifndef _TIMETYPE_H_
#define _TIMETYPE_H_

using namespace std;


class timeType
{
   public:
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      timeType(int hours = 0, int minutes = 0);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      string getAmPm() const;
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setAmPm(string&);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void getTime(int, int);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setTime(int, int);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      int getHours() const;
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setHours(int);
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      int getMinutes() const;
      
      // method - constructor
      // description - construct a new time type object
      // preconditions - none
      // postconditions - time type object created and initialized 
      //    to 0 by default
      // method input - hours/minutes: all ints
      // method output - none
      void setMinutes(int);

   private:
      string aMpM;    // variable to store the a.m./p.m. string
      int hours;       // variable to store the hour
      int minutes;    // variable to store the minutes
};


ostream& operator << (ostream&, const timeType&);   // overload the insertion stream operator

#endif
