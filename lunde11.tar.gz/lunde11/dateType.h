// Author: Todd Lunde
// File: dateType.h (Prog11)
// Class: CSIS 252
// Program: assignment 11
// Date: 12/01/2018   
                                      
                                                                                                                            
// This file contains the class specifications for the dateType class.                  

// dateType.h
#include <fstream>
#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
 
using namespace std;

#ifndef _DATETYPE_H_
#define _DATETYPE_H_


class dateType
{
   public:
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      dateType(int month = 1, int day = 1, int year = 2000);
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      void getDate(int, int, int);
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      void setDate(int, int, int);
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      int getMonth() const;
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      void setMonth(int);
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      int getDay() const;
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      void setDay(int);
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      int getYear() const;
      
      // method - default constructor
      // description - construct a date type object
      // preconditions - none
      // postconditions - date type object created and initialized 
      //    to date 1/1/2000 by default
      // method input - date: day/month/year: all ints
      // method output - none  
      void setYear(int);
      
   private:
      string sMonth;  // variable to store month name string
      int month;      // variable to store the month
      int day;        // variable to store the day
      int year;       // variable to store the year
};

ostream& operator<< (ostream&, const dateType&);

#endif


